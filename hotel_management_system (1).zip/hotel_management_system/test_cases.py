# test_cases.py
from models.guest import Guest
from models.room import Room
from models.booking import Booking
from models.feedback import Feedback
from models.service_request import ServiceRequest

# 1. Guest Account Creation
print("\n--- Test: Guest Account Creation ---")
g1 = Guest("Alice", "alice@example.com", "1234567890", 100)  # Create guest with loyalty points
g2 = Guest("Bob", "bob@example.com", "0987654321", 50)
print(g1)  # Display guest details
print(g2)

# 2. Searching for Available Rooms
print("\n--- Test: Searching for Available Rooms ---")
room1 = Room("101", "Single", ["Wi-Fi"], 100.0)  # Available room
room2 = Room("102", "Double", ["Wi-Fi", "TV"], 150.0, available=False)  # Unavailable room
rooms = [room1, room2]
available_rooms = [room for room in rooms if room.is_available()]  # Filter available rooms
for r in available_rooms:
    print(r)  # Display available room(s)

# 3. Making a Room Reservation
print("\n--- Test: Making a Room Reservation ---")
booking1 = Booking("2025-05-01", "2025-05-03", g1, room1)  # Booking for guest 1
room1.update_status(False)  # Mark room1 as unavailable after booking
print(booking1)

booking2 = Booking("2025-06-10", "2025-06-12", g2, room2)  # Booking for guest 2
room2.update_status(False)  # Mark room2 as unavailable after booking
print(booking2)

# 4. Booking Confirmation Notification
print("\n--- Test: Booking Confirmation Notification ---")
print(booking1.confirm_booking())  # Confirm booking1
print(booking2.confirm_booking())  # Confirm booking2

# 5. Invoice Generation for a Booking
print("\n--- Test: Invoice Generation ---")
print(booking1.invoice)  # Display invoice for booking1
print(booking2.invoice)  # Display invoice for booking2

# 6. Simulating Payment Processing (simple representation)
print("\n--- Test: Payment Processing ---")
print("Payment successful for:", booking1.guest._name)  # Simulated payment for guest 1
print("Payment successful for:", booking2.guest._name)  # Simulated payment for guest 2

# 7. Displaying Reservation History
print("\n--- Test: Displaying Reservation History ---")
for b in g1.view_history():
    print(b)  # Guest 1's reservation history
for b in g2.view_history():
    print(b)  # Guest 2's reservation history

# 8. Cancellation of a Reservation
print("\n--- Test: Cancellation of a Reservation ---")
print(booking1.cancel_booking())  # Cancel booking1
print(f"Room 101 available: {room1.is_available()}")  # Check availability after cancellation
print(booking2.cancel_booking())  # Cancel booking2
print(f"Room 102 available: {room2.is_available()}")  # Check availability after cancellation
